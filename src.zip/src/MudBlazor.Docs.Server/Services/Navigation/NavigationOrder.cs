﻿namespace MudBlazor.Docs.Server.Services;

public enum NavigationOrder
{
    Previous,
    Next
}
