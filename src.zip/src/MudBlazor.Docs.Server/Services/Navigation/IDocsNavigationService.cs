﻿using MudBlazor.Docs.Server.Models;

namespace MudBlazor.Docs.Server.Services;

public interface IDocsNavigationService
{
    NavigationFooterLink Next { get; }

    NavigationFooterLink Previous { get; }

    NavigationSection Section { get; }
}
