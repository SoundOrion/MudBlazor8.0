﻿// Copyright (c) MudBlazor 2021
// MudBlazor licenses this file to you under the MIT license.
// See the LICENSE file in the project root for more information.

namespace MudBlazor.Docs.Server.Pages.Api;

#nullable enable

/// <summary>
/// Represents a list of all MudBlazor components and related types.
/// </summary>
public partial class Index
{
}
