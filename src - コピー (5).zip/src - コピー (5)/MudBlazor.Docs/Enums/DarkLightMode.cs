﻿namespace MudBlazor.Docs.Enums;

public enum DarkLightMode
{
    System = 0,
    Light = 1,
    Dark = 2
}
