﻿namespace MudBlazor.Docs.Services.Notifications;

public record NotificationAuthor(string DisplayName, string AvatarUrl);
