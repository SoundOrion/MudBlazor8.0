﻿namespace MudBlazor.Docs.Services;

public enum NavigationOrder
{
    Previous,
    Next
}
