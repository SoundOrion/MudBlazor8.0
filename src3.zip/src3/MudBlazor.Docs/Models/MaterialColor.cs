﻿
namespace MudBlazor.Docs.Models
{
    public class MaterialColor
    {
        public string Color { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
